package cpen221.mp3.client;

public enum RequestType {
    CONFIG,
    CONTROL,
    ANALYSIS,
    PREDICT
}