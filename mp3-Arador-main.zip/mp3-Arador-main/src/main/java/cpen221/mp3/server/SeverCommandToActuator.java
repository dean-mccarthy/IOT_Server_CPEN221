package cpen221.mp3.server;

public enum SeverCommandToActuator {
    SET_STATE,
    TOGGLE_STATE
}