CONTRIBUTIONS
- Wrote the code for predictor model for both Nvalues and Ntimestamps
- Created tests for task 4
- removed unnecessary comments to follow the coding style 
 
