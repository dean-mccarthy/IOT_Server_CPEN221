# Contributions
* Implemented Task 2 Filter functions and some Server/Client Functions
* Wrote some tests for Task 2
* Maintained codestyle checks in code
